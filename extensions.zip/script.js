// 2025년 세마중학교 월별 급식표 데이터 (월별로 직접 수정 가능, 일 수와 급식만 수정)
const semaLunchMenu = {
    "1월": { "일수": 31, "급식": {} },
    "2월": { "일수": 28, "급식": {} },
    "3월": { "일수": 31, "급식": {} },
    "4월": { "일수": 30, "급식": {} },
    "5월": { "일수": 31, "급식": {} },
    "6월": { "일수": 30, "급식": {} },
    "7월": { "일수": 31, "급식": {} },
    "8월": { "일수": 31, "급식": {} },
    "9월": { "일수": 30, "급식": {} },
    "10월": { "일수": 31, "급식": {} },
    "11월": { "일수": 30, "급식": {} },
    "12월": { "일수": 31, "급식": {} }
};

// localStorage에서 불러오기
function loadLunchData() {
    const data = localStorage.getItem('semaLunchMenu');
    if (data) {
        const parsed = JSON.parse(data);
        for (const month in parsed) {
            if (semaLunchMenu[month]) {
                semaLunchMenu[month].급식 = parsed[month].급식;
            }
        }
    }
}

// localStorage에 저장
function saveLunchData() {
    localStorage.setItem('semaLunchMenu', JSON.stringify(semaLunchMenu));
}

// 예시: 3월 1일~3일만 급식 데이터 입력 (최초 실행 시만)
if (!localStorage.getItem('semaLunchMenu')) {
    semaLunchMenu["3월"].급식[1] = "김치볶음밥, 계란국, 오이무침";
    semaLunchMenu["3월"].급식[2] = "돈까스, 양배추샐러드, 미소된장국";
    semaLunchMenu["3월"].급식[3] = "비빔밥, 유부장국, 배추김치";
    saveLunchData();
}

loadLunchData();

const monthSelect = document.getElementById('monthSelect');
const lunchTableBody = document.querySelector('#lunchTable tbody');

// 월 셀렉트 박스 채우기
Object.keys(semaLunchMenu).forEach(month => {
    const option = document.createElement('option');
    option.value = month;
    option.textContent = month;
    monthSelect.appendChild(option);
});

let isEditMode = false;
const ADMIN_PW = 'sema1234'; // 비밀번호는 필요시 변경 가능

// 새로고침 후에도 수정모드 유지
if (localStorage.getItem('semaLunchEditMode') === 'true') {
    isEditMode = true;
    setTimeout(() => {
        editModeBtn.style.display = 'none';
        exitEditModeBtn.style.display = '';
        editModeInfo.textContent = '수정 모드: 급식 정보를 클릭해 수정할 수 있습니다.';
        renderLunchTable(monthSelect.value);
    }, 0);
}

const WRONG_MSGS = [
    '비밀번호가 틀렸습니다.',
    '다시 시도해주세요.'
];
let pwFailCount = Number(localStorage.getItem('semaLunchPwFailCount')) || 0;
let pwLockUntil = Number(localStorage.getItem('semaLunchPwLockUntil')) || 0;
let pwLockActive = localStorage.getItem('semaLunchPwLockActive') === 'true';
let pwTimerInterval = null;

function savePwLockState() {
    localStorage.setItem('semaLunchPwFailCount', pwFailCount);
    localStorage.setItem('semaLunchPwLockUntil', pwLockUntil);
    localStorage.setItem('semaLunchPwLockActive', pwLockActive);
}

function clearPwLockState() {
    localStorage.removeItem('semaLunchPwFailCount');
    localStorage.removeItem('semaLunchPwLockUntil');
    localStorage.removeItem('semaLunchPwLockActive');
}

function startPwTimer() {
    clearPwTimer();
    pwBox.classList.add('pw-disabled');
    pwTimerInterval = setInterval(() => {
        const now = Date.now();
        if (pwLockActive && now < pwLockUntil) {
            const remain = Math.ceil((pwLockUntil - now) / 1000);
            pwMsg.textContent = `잠시 후 다시 시도하세요. (${remain}초)`;
        } else {
            clearPwTimer();
            pwMsg.textContent = '';
            pwBox.style.display = 'none';
            pwBox.classList.remove('pw-disabled');
            pwLockActive = false;
            pwLockUntil = 0;
            pwFailCount = 0;
            clearPwLockState();
        }
    }, 200);
}

function clearPwTimer() {
    if (pwTimerInterval) {
        clearInterval(pwTimerInterval);
        pwTimerInterval = null;
    }
    pwBox.classList.remove('pw-disabled');
}

// 새로고침 시 제한 남아있으면 타이머 바로 시작
if (pwLockActive && Date.now() < pwLockUntil) {
    setTimeout(() => {
        pwBox.style.display = 'block';
        startPwTimer();
    }, 0);
}

const editModeBtn = document.getElementById('editModeBtn');
const exitEditModeBtn = document.getElementById('exitEditModeBtn');
const editModeInfo = document.getElementById('editModeInfo');
const pwBox = document.getElementById('pwBox');
const editPw = document.getElementById('editPw');
const pwSubmitBtn = document.getElementById('pwSubmitBtn');
const pwMsg = document.getElementById('pwMsg');

editModeBtn.onclick = () => {
    pwBox.style.display = 'block';
    editPw.value = '';
    pwMsg.textContent = '';
    editPw.focus();
    if (pwLockActive && Date.now() < pwLockUntil) {
        startPwTimer();
    } else {
        clearPwTimer();
    }
};

pwSubmitBtn.onclick = tryEditModeLogin;
editPw.addEventListener('keydown', e => {
    if (e.key === 'Enter') tryEditModeLogin();
});

function tryEditModeLogin() {
    const now = Date.now();
    if (editPw.value.trim() === '') {
        editPw.focus();
        return;
    }
    if (pwLockActive && now < pwLockUntil) {
        startPwTimer();
        editPw.value = '';
        editPw.blur();
        return;
    }
    if (editPw.value === ADMIN_PW) {
        isEditMode = true;
        localStorage.setItem('semaLunchEditMode', 'true');
        pwBox.style.display = 'none';
        editModeBtn.style.display = 'none';
        exitEditModeBtn.style.display = '';
        editModeInfo.textContent = '급식 정보를 볼 수 있습니다.';
        renderLunchTable(monthSelect.value);
        pwFailCount = 0;
        pwLockActive = false;
        pwLockUntil = 0;
        clearPwTimer();
        clearPwLockState();
    } else {
        pwFailCount++;
        // 랜덤 메시지
        pwMsg.textContent = WRONG_MSGS[Math.floor(Math.random() * WRONG_MSGS.length)];
        editPw.value = '';
        editPw.focus();
        if (pwFailCount >= 3) {
            pwLockActive = true;
            pwLockUntil = Date.now() + 60000;
            pwMsg.textContent = '비밀번호가 여러 번 틀렸습니다. 1분 후 다시 시도하세요.';
            editPw.blur();
            savePwLockState();
            startPwTimer();
        }
        // 1분 제한 이후에는 1회만 틀려도 바로 제한
        if (pwLockActive && pwFailCount >= 1 && now >= pwLockUntil) {
            pwLockUntil = Date.now() + 60000;
            pwMsg.textContent = '비밀번호가 여러 번 틀렸습니다. 1분 후 다시 시도하세요.';
            editPw.blur();
            savePwLockState();
            startPwTimer();
        }
        savePwLockState();
    }
}

exitEditModeBtn.onclick = () => {
    isEditMode = false;
    localStorage.removeItem('semaLunchEditMode');
    editModeBtn.style.display = '';
    exitEditModeBtn.style.display = 'none';
    editModeInfo.textContent = '급식 정보를 볼 수 있습니다.';
    renderLunchTable(monthSelect.value);
    clearPwTimer();
};

// 급식표 렌더링 함수 (수정: isEditMode 체크)
function renderLunchTable(month) {
    const { 일수, 급식 } = semaLunchMenu[month];
    lunchTableBody.innerHTML = '';
    for (let day = 1; day <= 일수; day++) {
        const tr = document.createElement('tr');
        const tdDay = document.createElement('td');
        tdDay.textContent = day + '일';
        const tdMenu = document.createElement('td');
        tdMenu.textContent = 급식[day] || '식단 정보 없음';
        tdMenu.classList.add('lunch-cell');
        if (isEditMode) {
            tdMenu.addEventListener('click', function () {
                if (tdMenu.classList.contains('editing')) return;
                tdMenu.classList.add('editing');
                const input = document.createElement('input');
                input.type = 'text';
                input.value = 급식[day] || '';
                input.className = 'lunch-edit';
                tdMenu.textContent = '';
                tdMenu.appendChild(input);
                input.focus();
                input.setSelectionRange(input.value.length, input.value.length);
                // 저장 함수
                function save() {
                    semaLunchMenu[month].급식[day] = input.value.trim();
                    saveLunchData();
                    renderLunchTable(month);
                }
                input.addEventListener('blur', save);
                input.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter') {
                        input.blur();
                    } else if (e.key === 'Escape') {
                        renderLunchTable(month);
                    }
                });
            });
        }
        tr.appendChild(tdDay);
        tr.appendChild(tdMenu);
        lunchTableBody.appendChild(tr);
    }
}

// 월 변경 시 이벤트
monthSelect.addEventListener('change', e => {
    renderLunchTable(e.target.value);
});

// 기본: 현재 달로 시작
const now = new Date();
const monthNames = ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
const thisMonth = monthNames[now.getMonth()];
if (semaLunchMenu[thisMonth]) {
    monthSelect.value = thisMonth;
    renderLunchTable(thisMonth);
} else {
    monthSelect.value = '3월';
    renderLunchTable('3월');
}

const darkModeToggle = document.getElementById('darkModeToggle');
function setDarkMode(on) {
    if (on) {
        document.body.classList.add('darkmode');
        darkModeToggle.innerHTML = '☀️ 라이트모드';
        localStorage.setItem('semaLunchDarkMode', 'true');
    } else {
        document.body.classList.remove('darkmode');
        darkModeToggle.innerHTML = '🌙 다크모드';
        localStorage.setItem('semaLunchDarkMode', 'false');
    }
}
darkModeToggle.onclick = () => {
    setDarkMode(!document.body.classList.contains('darkmode'));
};
// 페이지 로드 시 다크모드 상태 복원
if (localStorage.getItem('semaLunchDarkMode') === 'true') {
    setDarkMode(true);
}

const refreshBtn = document.getElementById('refreshBtn');
if (refreshBtn) {
  refreshBtn.onclick = () => { location.reload(); };
}

window.addEventListener('DOMContentLoaded', () => {
  const container = document.querySelector('.container');
  if (!sessionStorage.getItem('semalunchAnimated')) {
    container.classList.add('animate-in');
    sessionStorage.setItem('semalunchAnimated', 'true');
  }
  // 인트로 화면 처리
  const intro = document.getElementById('intro');
  if (intro) {
    let duration = 2200;
    // 네트워크 속도에 따라 로딩 지속시간 조절
    if (navigator.connection && navigator.connection.effectiveType) {
      const type = navigator.connection.effectiveType;
      if (type === '4g') duration = 1200;
      else if (type === '3g') duration = 2500;
      else if (type === '2g' || type === 'slow-2g') duration = 4000;
    }
    setTimeout(() => {
      intro.classList.add('hide');
      setTimeout(() => { intro.style.display = 'none'; }, 800);
    }, duration);
  }
}); 